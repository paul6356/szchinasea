{{ ucfunc("put_docready_start") }}
		
   var objList = jQuery("#{{uc_id}}");
  
   var objRemoteOptions = {
    	class_items:"uc_post_list_box",
    	class_active:"ue-active-item",
      	add_set_active_code:true
    };
  
  	{{ucfunc("put_remote_parent_js","objList","objRemoteOptions")}} 
    	
{{ ucfunc("put_docready_end") }}